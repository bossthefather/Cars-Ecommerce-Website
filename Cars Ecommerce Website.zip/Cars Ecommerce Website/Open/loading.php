<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loading...</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="Style/loading.css">
</head>
<body>
    <?php
    session_start();

    // Define role-based redirection paths
    $roleRedirects = [
        0 => 'admin.php',
        1 => 'customer.php',
        2 => 'seller.php'
    ];

    // Get the user role from session
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : null;

    // Determine the redirection page
    $redirectPage = isset($roleRedirects[$role]) ? $roleRedirects[$role] : 'index.php';

    // JavaScript to handle the redirection
    echo "<script>
        setTimeout(() => {
            window.location.href = '$redirectPage';
        }, 4000);
    </script>";
    ?>

    <div class="loading-container">
        <!-- Only Mercedes Logo -->
        <img src="Logo/mercedes-logo.png" alt="Mercedes Logo" class="mercedes-logo">
        <div class="loading-text">Loading, please wait...</div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
