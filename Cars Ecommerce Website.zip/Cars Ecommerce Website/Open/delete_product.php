<?php
include_once "connection.php";  // Include database connection
include_once "functions.php";  // Include any utility functions

session_start(); // Start the session

// Ensure the user is logged in and is a seller (role 2 means seller)
if (!isset($_SESSION["id"]) || $_SESSION["role"] != 2) {  // Only sellers (role = 2) can delete products
    header("Location: index.php");  // Redirect if not logged in or not a seller
    exit();
}

if (isset($_POST["delete_product"])) {
    $product_id = $_POST["id"];  // Get the product ID from the form input

    // Check if the product exists and belongs to the logged-in seller
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? AND fk_id = ?");
    $stmt->execute([$product_id, $_SESSION["id"]]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        // Delete the product image if it exists
        if ($product["image"]) {
            unlink("image/" . $product["image"]);
        }

        // Delete the product from the database
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ? AND fk_id = ?");
        $stmt->execute([$product_id, $_SESSION["id"]]);
    }

    // Redirect back to the seller's dashboard
    header("Location: seller.php");
    exit();
}
