<?php
session_start(); // Start the session

// Database connection details
$host = 'localhost';
$dbname = 'st023373';
$username = 'root';
$password = '';

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize error message
$error_message = "";

// Login
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["login"])) {
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
    $password = $_POST["password"];

    // Fetch user by email
    $stmt = $conn->prepare("SELECT * FROM users WHERE Email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user["Password"])) {
        // Set session variables
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["role"] = $user["Role"];
        $_SESSION["name"] = $user["Name"];

        // Redirect based on role
        switch ($user["Role"]) {
            case 0: // Admin
                header("Location: loading.php?redirect=admin.php");
                exit();
            case 1: // Customer
                header("Location: loading.php?redirect=customer.php");
                exit();
            case 2: // Seller
                header("Location: loading.php?redirect=seller.php");
                exit();
            default:
                $error_message = "Invalid role. Please contact support.";
        }
    } else {
        $error_message = "Invalid email or password.";
    }
}

// Handle Registration
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["register"])) {
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
    $name = htmlspecialchars($_POST["name"]);
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $role = $_POST["role"];

    // Check if email already exists
    $checkStmt = $conn->prepare("SELECT * FROM users WHERE Email = ?");
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        $error_message = "Email already exists. Please try again.";
    } else {
        // Insert new user
        $stmt = $conn->prepare("INSERT INTO users (Name, Email, Password, Role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $name, $email, $password, $role);
        $stmt->execute();

        // Set session and redirect
        $_SESSION["id"] = $conn->insert_id;
        $_SESSION["Role"] = $role;
        $_SESSION["Name"] = $name;

        switch ($role) {
            case 0: // Admin
                header("Location: loading.php?redirect=admin.php");
                exit();
            case 2: // Seller
                header("Location: loading.php?redirect=seller.php");
                exit();
            case 1: // Customer
                header("Location: loading.php?redirect=customer.php");
                exit();
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideIT - Sign Up.</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style/footer.css">
    <link rel="stylesheet" href="Style/index1.css">
    <style>

    /* Video */
    .background-video {
    position: fixed;
    top: 0;
    left: 0;
    min-width: 100%;
    min-height: 100%;
    width: auto;
    height: auto;
    z-index: -1;
    object-fit: cover; 
    filter: contrast(1.2) brightness(1.1); 
}
    </style>
</head>

<?php
include("header.php");
?>
<body>
    <!-- Background Video -->
    <video autoplay muted loop class="background-video">
        <source src="Video/merc.mp4" type="video/mp4">
    </video>

    <div class="container mt-5">
        <h1 class="text-center">Sign Up.</h1>
        <!-- Error Message -->
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error_message) ?></div>
        <?php endif; ?>

        <!-- Tabs -->
        <ul class="nav nav-tabs" id="tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="login-tab" data-toggle="tab" href="#login" role="tab">Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="register-tab" data-toggle="tab" href="#register" role="tab">Register</a>
            </li>
        </ul>

        <div class="tab-content mt-3">
            <!-- Login Form -->
            <div class="tab-pane fade show active" id="login" role="tabpanel">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" name="password" placeholder="Enter your password" required>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary my-4">Login</button>
                </form>
            </div>

            <!-- Register Form -->
            <div class="tab-pane fade" id="register" role="tabpanel">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" name="name" placeholder="Enter your name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" name="password" placeholder="Enter your password" required>
                    </div>
                    <div class="form-group">
                        <label for="role">Role:</label>
                        <select class="form-control" name="role">
                            <option value="1">Customer</option>
                            <option value="2">Seller</option>
                            <option value="0">Admin</option>
                        </select>
                    </div>
                    <button type="submit" name="register" class="btn btn-primary my-4">Register</button>
                </form>
            </div>
        </div>
    </div>
    <?php include("footer.php") ?>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
