<?php
session_start();
include_once "connection.php";

// Ensure the user is logged in as a customer
if (!isset($_SESSION["id"]) || $_SESSION["role"] != 1&2&0) {  
    header("Location: index.php");  
    exit();
}

$id = $_SESSION["id"];  

// Check if the user exists in the users table
$stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
$stmt->execute([$id]);
$user_exists = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user_exists) {
    echo "User does not exist!";
    exit();
}

// Fetch products from the `products` table
$stmt = $pdo->prepare("SELECT * FROM products WHERE stock > 0");
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

//  Add to Cart
if (isset($_POST['add_product'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Ensure the product exists in the products table
    $stmt = $pdo->prepare("SELECT id FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product_exists = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product_exists) {
        echo "Product does not exist!";
        exit();  // Stop execution if product doesn't exist
    }

    // Check if the product already exists in the cart
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['quantity'] += $quantity;
    } else {
        // Insert a new product into the cart
        $stmt = $pdo->prepare("SELECT price FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        $_SESSION['cart'][$product_id] = [
            'product_id' => $product_id,
            'quantity' => $quantity,
            'price' => $product['price']
        ];
    }

    // Update stock in the products table (optional)
    $stmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    $new_stock = $product['stock'] - $quantity;
    $stmt = $pdo->prepare("UPDATE products SET stock = ? WHERE id = ?");
    $stmt->execute([$new_stock, $product_id]);

    header("Location: customer.php");
    exit();
}

// Handle Update Quantity
if (isset($_POST['update_quantity'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    if ($quantity > 0) {
        $_SESSION['cart'][$product_id]['quantity'] = $quantity;
    } else {
        // If quantity is zero or less, delete the product from the cart
        unset($_SESSION['cart'][$product_id]);
    }

    header("Location: cart.php");
    exit();
}

// Handle Delete Product
if (isset($_POST['delete_product'])) {
    $product_id = $_POST['product_id'];

    unset($_SESSION['cart'][$product_id]);

    header("Location: cart.php");
    exit();
}

// Fetch Cart Items
$cart_items = [];
$total_amount = 0;

if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $cart_item) {
        $stmt = $pdo->prepare("SELECT name, price FROM products WHERE id = ?");
        $stmt->execute([$cart_item['product_id']]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        $subtotal = $product['price'] * $cart_item['quantity'];
        $cart_items[] = [
            'product_id' => $cart_item['product_id'],
            'name' => $product['name'],
            'price' => $product['price'],
            'quantity' => $cart_item['quantity'],
            'subtotal' => $subtotal
        ];

        $total_amount += $subtotal;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideIT - Cart</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel = "stylesheet" href = "Style/cart1.css">
    <link rel = "stylesheet" href = "Style/footer.css">
</head>
<body>
    <?php include('header_customers.php'); ?>

    <div class="container mt-5">
        <h2>Your Personal Cart</h2>

        <?php if (!empty($cart_items)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Car Model</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['name']) ?></td>
                            <td>$<?= number_format($item['price'], 2) ?></td>
                            <td>
                                <form action="cart.php" method="POST" class="form-inline">
                                    <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" class="form-control mr-2" required>
                                    <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                                    <button type="submit" name="update_quantity" class="btn btn-primary btn-sm">Update</button>
                                </form>
                            </td>
                            <td>$<?= number_format($item['subtotal'], 2) ?></td>
                            <td>
                                <form action="cart.php" method="POST">
                                    <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                                    <button type="submit" name="delete_product" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" class="text-right"><strong>Total:</strong></td>
                        <td colspan="2"><strong>$<?= number_format($total_amount, 2) ?></strong></td>
                    </tr>
                </tfoot>
            </table>
            <form action="orders.php" method="POST">
                <button type="submit" name="place_order" class="btn btn-success">Place Order</button>
            </form>
        <?php else: ?>
            <p><div class="alert alert-primary">Your cart is empty!</div></p>
        <?php endif; ?>
    </div>
    <?php include("footer.php")?>
</body>
</html>
