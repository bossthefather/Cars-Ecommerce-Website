<?php
include_once "connection.php";  // Include database connection
include_once "functions.php";  // Include any utility functions

session_start(); // Start the session

// Ensure the user is logged in and is a seller (role 2 means seller)
if (!isset($_SESSION["id"]) || $_SESSION["role"] != 2) {  // Only sellers (role = 2) can edit products
    header("Location: index.php");  // Redirect if not logged in or not a seller
    exit();
}

$product_id = $_GET['id']; // Get the product ID from the URL

// Fetch the product from the database
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? AND fk_id = ?");
$stmt->execute([$product_id, $_SESSION['id']]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    // Product not found or not owned by the seller
    header("Location: seller.php");  // Redirect to the seller's dashboard if product is not found
    exit();
}

// Handle the form submission (updating product details)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $price = $_POST["price"];
    $stock = $_POST["stock"];
    $description = htmlspecialchars($_POST["description"]);
    
    // If a new image is uploaded
    $image = $_FILES["image"]["name"];
    $tmp_image = $_FILES["image"]["tmp_name"];
    $image_path = $product["image"];  // Default to current image if no new image is uploaded

    // Handle the image upload if a new image is selected
    if ($image) {
        $upload_dir = "image/";  // Directory to store uploaded images
        $image_path = time() . "_" . basename($image);  // New image name to avoid conflict
        move_uploaded_file($tmp_image, $upload_dir . $image_path);  // Move uploaded image to target directory
    }

    // Update the product in the database
    $stmt = $pdo->prepare("UPDATE products SET name = ?, price = ?, stock = ?, description = ?, image = ? WHERE id = ? AND fk_id = ?");
    $stmt->execute([$name, $price, $stock, $description, $image_path, $product_id, $_SESSION['id']]);

    // Redirect back to the seller's dashboard
    header("Location: seller.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style/footer.css">
</head>
<body>
    <?php include("header_customers.php") ?> <!-- Include header for customers -->

    <div class="container mt-5">
        <h2>Edit Product</h2>
        
        <!-- Display product details in the form for editing -->
        <form action="edit_product.php?id=<?= $product['id'] ?>" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Car Model</label>
                <input type="text" class="form-control" name="name" id="name" value="<?= htmlspecialchars($product['name']) ?>" required>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" class="form-control" name="price" id="price" value="<?= htmlspecialchars($product['price']) ?>" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="stock">Stock Quantity</label>
                <input type="number" class="form-control" name="stock" id="stock" value="<?= htmlspecialchars($product['stock']) ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Car Description</label>
                <textarea class="form-control" name="description" id="description" rows="4" required><?= htmlspecialchars($product['description']) ?></textarea>
            </div>
            <div class="form-group">
                <label for="image">Upload New Image (optional)</label>
                <input type="file" class="form-control" name="image" id="image" accept="image/*">
                <?php if ($product['image']): ?>
                    <p>Current Image: <img src="image/<?= htmlspecialchars($product['image']) ?>" width="100" alt="<?= htmlspecialchars($product['name']) ?>"></p>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-success">Save Changes</button>
        </form>
    </div>

    <!-- JS Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
