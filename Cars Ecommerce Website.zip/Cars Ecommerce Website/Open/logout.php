<?php

// set the expiration date to one hour ago
setcookie("user", $username, time() - 3600, "/");

header("Location: index.php");
?>