<?php
session_start();
include_once "connection.php";

// Ensure the user is logged in as a customer
if (!isset($_SESSION["id"]) || $_SESSION["role"] != 1&2&0) {  
    header("Location: index.php");  
    exit();
}

$user_id = $_SESSION["id"];

// Handle Add to Wishlist
if (isset($_POST['add_wishlist'])) {
    $product_id = $_POST['product_id'];

    // Check if the product already exists in the wishlist
    $stmt = $pdo->prepare("SELECT * FROM wishlist WHERE id = ? AND product_id = ?");
    $stmt->execute([$user_id, $product_id]);
    $existing_product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$existing_product) {
        // If the product is not in the wishlist, add it
        $stmt = $pdo->prepare("INSERT INTO wishlist (id, product_id) VALUES (?, ?)");
        $stmt->execute([$user_id, $product_id]);
    }

    header("Location: wishlist.php");  // Refresh the page after adding an item
    exit();
}

// Handle Remove from Wishlist
if (isset($_POST['remove_wishlist'])) {
    $product_id = $_POST['product_id'];

    // Remove the product from the wishlist
    $stmt = $pdo->prepare("DELETE FROM wishlist WHERE id = ? AND product_id = ?");
    $stmt->execute([$user_id, $product_id]);

    header("Location: wishlist.php");  // Refresh the page after removing an item
    exit();
}

// Fetch products in the user's wishlist
$stmt = $pdo->prepare("SELECT p.* FROM products p
                       INNER JOIN wishlist w ON p.id = w.product_id
                       WHERE w.id = ?");
$stmt->execute([$user_id]);
$wishlist = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideIT - Wishlist</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style/1wishlist.css">
    <link rel="stylesheet" href="Style/footer.css">
</head>
<body>
    <?php include('header_customers.php'); ?>

    <div class="container mt-5">
        <h2>Your Wishlist</h2>

        <!-- Display Wishlist -->
        <div class="row">
            <?php if (count($wishlist) > 0): ?>
                <?php foreach ($wishlist as $product): ?>
                    <div class="col-md-4">
                        <div class="card mb-3">
                            <img src="image/<?= htmlspecialchars($product['image']) ?>" class="card-img-top" >
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                                <p class="card-text">Price: $<?= htmlspecialchars($product['price']) ?></p>
                                <p class="card-text"><?= htmlspecialchars($product['description']) ?></p>
                                <form action="wishlist.php" method="POST">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <button type="submit" name="remove_wishlist" class="btn btn-danger">Remove from Wishlist</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p><div class="alert alert-primary">No products in your wishlist</div></p>
            <?php endif; ?>
        </div>
    </div>
    <?php include("footer.php")?>
</body>
</html>
