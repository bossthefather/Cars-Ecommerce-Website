<?php
// Set database connection variables
$host = 'localhost';
$dbname = 'st023373';  
$username = 'root'; 
$password = '';   

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare("SELECT id, Name, Email FROM users");
    $stmt->execute();

    // Fetch results
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);


} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
