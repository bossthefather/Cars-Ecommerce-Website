<?php
include_once "connection.php";
session_start();

// Ensure the user is logged in
if (!isset($_SESSION["id"])) {
    header("Location: index.php");
    exit();
}

$userId = $_SESSION["id"];
$userName = $_SESSION["name"]; // Assuming user's name is stored in session

// Handle placing the order from cart
if (isset($_POST['place_order'])) {
    // Check if the cart is empty
    if (empty($_SESSION['cart'])) {
        echo "Your cart is empty!";
        exit();
    }

    // Calculate total amount
    $totalAmount = 0;
    foreach ($_SESSION['cart'] as $cart_item) {
        $stmt = $pdo->prepare("SELECT price FROM products WHERE id = ?");
        $stmt->execute([$cart_item['product_id']]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        $totalAmount += $product['price'] * $cart_item['quantity'];
    }

    // Insert the order into the `orders` table
    $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount) VALUES (?, ?)");
    $stmt->execute([$userId, $totalAmount]);

    // Get the last inserted order ID
    $orderId = $pdo->lastInsertId();

    // Insert order details into `order_details` table
    foreach ($_SESSION['cart'] as $cart_item) {
        $stmt = $pdo->prepare("SELECT price FROM products WHERE id = ?");
        $stmt->execute([$cart_item['product_id']]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        // Insert each product in the cart into the order_details table
        $stmt = $pdo->prepare("INSERT INTO order_details (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        $stmt->execute([$orderId, $cart_item['product_id'], $cart_item['quantity'], $product['price']]);
    }

    // Clear the cart after placing the order
    unset($_SESSION['cart']);

    // Redirect to the orders page (or order confirmation page)
    header("Location: orders.php");
    exit();
}

// Fetch order summaries with total amount and created_at date
$orderSummaryStmt = $pdo->prepare(
    "SELECT o.id AS order_id, o.total_amount, o.created_at 
     FROM orders o 
     WHERE o.user_id = ? 
     ORDER BY o.created_at DESC"
);
$orderSummaryStmt->execute([$userId]);
$orderSummaries = $orderSummaryStmt->fetchAll(PDO::FETCH_ASSOC);

// Initialize order details array
$orderDetails = [];

// Fetch detailed products for each order
if (!empty($orderSummaries)) {
    foreach ($orderSummaries as $summary) {
        $orderDetailStmt = $pdo->prepare(
            "SELECT p.id AS product_id, p.name AS product_name, p.price AS product_price, 
                    p.image AS product_image, p.description AS product_description, 
                    od.quantity, (od.quantity * p.price) AS total_price 
             FROM order_details od 
             JOIN products p ON od.product_id = p.id 
             WHERE od.order_id = ?"
        );
        $orderDetailStmt->execute([$summary["order_id"]]);
        $orderDetails[$summary["order_id"]] = $orderDetailStmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideIT - Orders</title>

    <!-- Bootstrap Styling -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="Style/order1.css">
    <link rel="stylesheet" href="Style/footer.css">
</head>
<body>
<div class="wrapper">
    <?php include "header_customers.php"; ?>

    <div class="content">
        <div class="container">
            <h2 class="mb-4">Your Orders</h2>

            <!-- Display if no orders have been placed -->
            <?php if (empty($orderSummaries)): ?>
                <div class="alert alert-info">You haven't placed any orders yet.</div>
            <?php else: ?>
                <?php foreach ($orderSummaries as $summary): ?>
                    <div class="order-summary mb-5">
                        <h4>Order ID: <?php echo htmlspecialchars($summary["order_id"]); ?></h4>
                        <p><strong>Date:</strong> <?php echo htmlspecialchars($summary["created_at"]); ?></p>
                        <p><strong>Total Amount:</strong> €<?php echo htmlspecialchars(number_format($summary["total_amount"], 2)); ?></p>

                        <h5>Order Details</h5>
                        <table class="table table-striped table-hover order-details-table">
                            <thead>
                                <tr>
                                    <th>Car ID</th>
                                    <th>Car Name</th>
                                    <th>Unit Price</th>
                                    <th>Quantity</th>
                                    <th>Total Price</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($orderDetails[$summary["order_id"]])): ?>
                                    <?php foreach ($orderDetails[$summary["order_id"]] as $detail): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($detail["product_id"]); ?></td>
                                            <td><?php echo htmlspecialchars($detail["product_name"]); ?></td>
                                            <td>€<?php echo htmlspecialchars(number_format($detail["product_price"], 2)); ?></td>
                                            <td><?php echo htmlspecialchars($detail["quantity"]); ?></td>
                                            <td>€<?php echo htmlspecialchars(number_format($detail["total_price"], 2)); ?></td>
                                            <td><?php echo htmlspecialchars($detail["product_description"]); ?></td>
                                            <td>
                                                <?php 
                                                    // Ensure the image URL is correct
                                                    $imagePath = htmlspecialchars($detail["product_image"]);
                                                    
                                                    // If the image path is a relative path, append it to the base URL
                                                    $imageUrl = 'image/' . $imagePath; 
                                                ?>
                                                <img src="<?php echo $imageUrl; ?>" 
                                                     alt="Image" 
                                                     style="width: 50px; height: 50px;">
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No orders found for this order.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php require "footer.php"; ?>
</div>

<script src='https://code.jquery.com/jquery-3.5.1.slim.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js'></script>
<script src='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js'></script>
</body>
</html>
