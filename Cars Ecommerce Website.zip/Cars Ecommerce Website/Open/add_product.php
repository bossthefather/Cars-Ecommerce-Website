<?php
include_once "connection.php";
include_once "functions.php";

// Start session to ensure the user is logged in
session_start();

// Ensure the user is logged in and is a seller
if (!isset($_SESSION["id"]) || $_SESSION["role"] != 2) {  // Available ONLY for seller :))
    header("Location: index.php");  // Not seller -> signout.
    exit();
}

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $price = $_POST["price"];
    $stock = $_POST["stock"];
    $description = htmlspecialchars($_POST["description"]);

    // Handle the single file upload for the product image
    $image = $_FILES["image"]["name"];
    $tmp_image = $_FILES["image"]["tmp_name"];
    $upload_dir = "image/";  
    $image_path = "";

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Generate a unique name for the image to avoid filename conflicts
    $unique_image_name = time() . "_" . basename($image);
    $image_path = $upload_dir . $unique_image_name;

    // Try uploading the image
    if (move_uploaded_file($tmp_image, $image_path)) {
        // Insert product into the database
        $stmt = $pdo->prepare("INSERT INTO products (name, price, stock, description, fk_id, image) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $price, $stock, $description, $_SESSION["id"], $unique_image_name]);

        // Redirect to the seller's dashboard or another page after successfully adding the product
        header("Location: seller.php");
        exit();
    } else {
        $error_message = "Failed to upload the image. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideIT - Sell Product</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style/add_product.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Sell Your Car</h2>

        <!-- Error message if fail :( -->
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?= $error_message ?></div>
        <?php endif; ?>

        <!-- Product add form -->
        <form action="add_product.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Car Model</label>
                <input type="text" class="form-control" name="name" id="name" required>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" class="form-control" name="price" id="price" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="stock">Stock Quantity</label>
                <input type="number" class="form-control" name="stock" id="stock" required>
            </div>
            <div class="form-group">
                <label for="description">Car Description</label>
                <textarea class="form-control" name="description" id="description" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="image">Upload Image</label>
                <input type="file" class="form-control" name="image" id="image" accept="image/*" required>
            </div>
            <button type="submit" class="btn btn-success">Add Product</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
