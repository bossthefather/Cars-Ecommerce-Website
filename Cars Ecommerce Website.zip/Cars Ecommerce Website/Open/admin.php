<?php
require "header.php";
include_once "connection.php";
include_once "functions.php";

start_session();


// Check if user is logged in
if (!isset($_SESSION["id"]) || $_SESSION["role"] != 0) {  // Only for admin :)
    header("Location: index.php");  // If not admin -> signout.
    exit();
}

// User session variables
$Name = $_SESSION["name"];

// Fetch all users
$stmt = $pdo->prepare("SELECT * FROM users");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["edit_user"])) {
        $id = $_POST["id"];
        $Email = filter_var($_POST["Email"], FILTER_SANITIZE_EMAIL);
        $Name = htmlspecialchars($_POST["Name"]);
        $Role = $_POST["Role"];

        $stmt_update = $pdo->prepare("UPDATE users SET Email = ?, Name = ?, Role = ? WHERE id = ?");
        $stmt_update->execute([$Email, $Name, $Role, $id]);
    } elseif (isset($_POST["delete_user"])) {
        // Handle user deletion
        $idToDelete = $_POST["delete_user_id"];
        $stmt_delete = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt_delete->execute([$idToDelete]);

        
    }
    header("Location: " . htmlspecialchars($_SERVER["PHP_SELF"]));
    exit();
}

// Clear output buffer to remove accidental whitespace
ob_end_clean();
?>

    <style>

/* Video */
.background-video {
position: fixed;
top: 0;
left: 0;
min-width: 100%;
min-height: 100%;
width: auto;
height: auto;
z-index: -1;
object-fit: cover; 
filter: contrast(1.2) brightness(1.1); 
}
</style>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideIT - Admin</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="Style/admin.css">
    <link rel = "stylesheet" href = "Style/header.css">
    <link rel = "stylesheet" href = "Style/footer.css">
    <link rel = "stylesheet" href = "Style/admin.css">
</head>
<video autoplay muted loop class="background-video">
        <source src="Video/merc.mp4" type="video/mp4">
</video>
<body>
<?php
include ("header_admin.php");
?>
    <div class="wrapper">
        <div class="content">

            <div class="container mt-5">
                <h2 class="mb-4">Users List</h2>

                <!-- Sign Out Button -->
                <div class="d-flex justify-content-end mb-3">
                    <form action="logout.php" method="post">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-sign-out-alt"></i> Sign Out
                        </button>
                    </form>
                </div>

                <!-- User Table -->
                <table class="table table-bordered table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Email</th>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= htmlspecialchars($user["id"]) ?></td>
                                <td><?= htmlspecialchars($user["Email"]) ?></td>
                                <td><?= htmlspecialchars($user["Name"]) ?></td>
                                <td><?= getUserRole($user["Role"]) ?></td>
                                <td>
                                    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#editUserModal<?= $user["id"] ?>">
                                        Edit
                                    </button>
                                    <form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post" style="display: inline-block;" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                        <input type="hidden" name="delete_user_id" value="<?= htmlspecialchars($user["id"]) ?>">
                                        <button type="submit" class="btn btn-danger" name="delete_user">Delete</button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Edit User Modal -->
                            <div class="modal fade" id="editUserModal<?= $user["id"] ?>" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <input type="hidden" name="id" value="<?= htmlspecialchars($user["id"]) ?>">
                                                <div class="form-group">
                                                    <label for="Email">Email:</label>
                                                    <input type="email" class="form-control" name="Email" value="<?= htmlspecialchars($user["Email"]) ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="Name">Name:</label>
                                                    <input type="text" class="form-control" name="Name" value="<?= htmlspecialchars($user["Name"]) ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="Role">Role:</label>
                                                    <select class="form-control" name="Role">
                                                        <option value="0" <?= $user["Role"] == 0 ? "selected" : "" ?>>Admin</option>
                                                        <option value="1" <?= $user["Role"] == 1 ? "selected" : "" ?>>Customer</option>
                                                        <option value="2" <?= $user["Role"] == 2 ? "selected" : "" ?>>Seller</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary" name="edit_user">Save Changes</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
<?php include("footer.php"); ?>
</html>

<?php
function getUserRole($Role) {
    switch ($Role) {
        case 0:
            return "Admin";
        case 1:
            return "Customer";
        case 2:
            return "Seller";
        default:
            return "UnRegistered";
    }
}
?>
