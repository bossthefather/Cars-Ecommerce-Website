<footer class="footer">
    <p>&copy; <?php echo date("Y"); ?> by Charalambos Theodosidis. All Rights Reserved.</p>
</footer>