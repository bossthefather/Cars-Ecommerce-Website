<?php
include_once "connection.php";
include_once "functions.php";

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$Name = $_SESSION["name"] ?? "Guest";

?>
    <link href="Style/header.css" rel="stylesheet">
<header class="header">
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="customer.php" style="color:rgb(16, 226, 245);">
            <i class="fas fa-home"></i> <?php echo $Name; ?>'s Dashboard
        </a>
        <div class="ml-auto">
            <form action="logout.php" method="post" class="d-flex align-items-center">
                <a href="cart.php" class="btn btn-success mr-2">
                    <i class="fas fa-shopping-cart"></i> Cart
                </a>
                <a href="wishlist.php" class="btn btn-warning mr-2">
                    <i class="fas fa-heart"></i> Wishlist
                </a>
                <a href="orders.php" class="btn btn-info mr-2">
                    <i class="fas fa-box"></i> Orders
                </a>
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-sign-out-alt"></i> Sign Out
                </button>
            </form>
        </div>
    </nav>
</header>