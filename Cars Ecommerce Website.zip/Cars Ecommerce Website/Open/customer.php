<?php
session_start();
include_once "connection.php";

// Ensure the user is logged in as a customer
if (!isset($_SESSION["id"]) || $_SESSION["role"] != 1&2&0) {  
    header("Location: index.php");  // Check for login
    exit();
}

$user_id = $_SESSION["id"];

// Fetch products from the `products` table
$stmt = $pdo->prepare("SELECT * FROM products WHERE stock > 0");
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle Add to Cart
if (isset($_POST['add_product'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Check if the requested quantity is available in stock
    $stmt = $pdo->prepare("SELECT stock, price FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product && $quantity <= $product['stock']) {
        // If the cart doesn't exist in the session, create it
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Check if the product is already in the cart
        if (isset($_SESSION['cart'][$product_id])) {
            // Update the quantity if the product is already in the cart
            $_SESSION['cart'][$product_id]['quantity'] += $quantity;
        } else {
            // Add the product to the cart if it's not already there
            $_SESSION['cart'][$product_id] = [
                'product_id' => $product_id,
                'quantity' => $quantity,
                'price' => $product['price'],
            ];
        }

        // Decrease the stock in the products table (optional depending on your logic)
        $new_stock = $product['stock'] - $quantity;
        $stmt = $pdo->prepare("UPDATE products SET stock = ? WHERE id = ?");
        $stmt->execute([$new_stock, $product_id]);

        // Redirect to the cart page or customer page
        header("Location: cart.php");
        exit();
    } else {
        // If the requested quantity exceeds the available stock, show an error message
        echo "<script>alert('Not enough stock available');</script>";
    }
}

// Handle Add to Wishlist
if (isset($_POST['add_wishlist'])) {
    $product_id = $_POST['product_id'];

    // Check if the product is already in the wishlist
    $stmt = $pdo->prepare("SELECT * FROM wishlist WHERE id = ? AND product_id = ?");
    $stmt->execute([$user_id, $product_id]);
    $wishlist_item = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$wishlist_item) {
        // Insert the product into the wishlist if it's not already there
        $stmt = $pdo->prepare("INSERT INTO wishlist (id, product_id) VALUES (?, ?)");
        $stmt->execute([$user_id, $product_id]);
    }

    header("Location: customer.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideIT - MarketPlace</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style/footer.css">
    <link rel="stylesheet" href="Style/customers1.css">
</head>
<body>
    <?php include("header_customers.php") ?>
    <div class="container mt-5">

        <!-- Display Available Products -->
        <h3><strong>Available Products</strong></h3>
        <div class="row">
            <?php foreach ($products as $product): ?>
                <div class="col-md-4">
                    <div class="card mb-3">
                        <img src="image/<?= htmlspecialchars($product['image']) ?>" class="card-img-top" alt="Product Image">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                            <h6 class="card-text">Price: $<?= htmlspecialchars($product['price']) ?></h6>
                            <p class="card-text">Stock: <?= htmlspecialchars($product['stock']) ?></p>
                            <p class="card-text">Description: <?= htmlspecialchars($product['description']) ?></p>

                            <!-- Add to Cart form -->
                            <form action="customer.php" method="POST">
                                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                <input type="number" name="quantity" value="1" min="1" max="<?= $product['stock'] ?>" class="form-control mb-2" required>
                                <button type="submit" name="add_product" class="btn btn-success mt-3">Add to Cart</button>
                            </form>

                            <!-- Add to Wishlist form -->
                            <form action="customer.php" method="POST">
                                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                <button type="submit" name="add_wishlist" class="btn btn-info mt-3">Add to Wishlist</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div>
        <?php include("footer.php"); ?>
    </div>
</body>
</html>
