<?php
include_once "connection.php";  // Include database connection
include_once "functions.php";  // Include any utility functions

session_start(); // Start the session

if (!isset($_SESSION["id"]) || $_SESSION["role"] != 2&1&0) { 
    header("Location: index.php");  
    exit();
}

$user_id = $_SESSION["id"]; // The logged-in seller's ID

// Fetch all products for the logged-in seller using the seller's `id`
$stmt = $pdo->prepare("SELECT * FROM products WHERE fk_id = ?");  // Use `fk_id` to fetch seller's products
$stmt->execute([$user_id]);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

$Name = $_SESSION["name"] ?? "Guest"; // Fetch seller's name from the session (fallback to "Guest" if not set)
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RideIT - <?php echo htmlspecialchars($Name); ?>'s Dashboard</title>

    <!-- Bootstrap & FontAwesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="Style/header.css">
    <link rel="stylesheet" href="Style/seller.css">
    <link rel="stylesheet" href="Style/footer.css">
</head>
<body>
    <?php include("header_customers.php") ?> <!-- Include header for customers -->

    <div class="container mt-5">
        <h2><?php echo htmlspecialchars($Name); ?>'s Dashboard</h2>

        <!-- Add New Product Button -->
        <div class="d-flex justify-content-end mb-3">
            <a href="add_product.php" class="btn btn-success">
                <i class="fas fa-plus"></i> Sell Your Car
            </a>
        </div>
        
        <!-- Seller's Products -->
        <div class="mt-4">
            <h3>Your Products</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Car ID</th>
                        <th>Car Model</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($products) > 0): ?>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?= htmlspecialchars($product["id"]) ?></td>
                                <td><?= htmlspecialchars($product["name"]) ?></td>
                                <td>$<?= htmlspecialchars($product["price"]) ?></td>
                                <td><?= htmlspecialchars($product["stock"]) ?></td>
                                <td><?= htmlspecialchars($product["description"]) ?></td>
                                <td>
                                    <?php if ($product["image"]): ?>
                                        <img src="image/<?= htmlspecialchars($product["image"]) ?>" alt="<?= htmlspecialchars($product["name"]) ?>" width="100">
                                    <?php else: ?>
                                        No image uploaded
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <!-- Edit and Delete buttons -->
                                    <a href="edit_product.php?id=<?= $product["id"] ?>" class="btn btn-info">Edit</a>
                                    <form action="delete_product.php" method="post" style="display: inline-block;" onsubmit="return confirm('Are you sure you want to delete this product?');">
                                        <input type="hidden" name="id" value="<?= $product["id"] ?>">
                                        <button type="submit" class="btn btn-danger" name="delete_product">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7">You have no products listed yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- JS Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <?php include "footer.php"; ?> <!-- Include footer -->
</body>
</html>
