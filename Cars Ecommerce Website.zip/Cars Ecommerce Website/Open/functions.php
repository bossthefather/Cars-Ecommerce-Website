<?php

function start_session()
{
    if (session_status() == PHP_SESSION_NONE)
    {
        session_start();
    }
}

function destroy_session()
{
    session_start();
    session_destroy();
}

?>